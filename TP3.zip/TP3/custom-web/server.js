const express = require('express');
const morgan = require('morgan');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

const logDirectory = path.join(__dirname, 'logs');
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory);

const accessLogStream = fs.createWriteStream(
  path.join(logDirectory, 'access.log'), 
  { flags: 'a' }
);

app.use(morgan((tokens, req, res) => {
  return JSON.stringify({
    'method': tokens.method(req, res),
    'url': tokens.url(req, res),
    'status': parseInt(tokens.status(req, res)),
    'response-time': parseFloat(tokens['response-time'](req, res)),
    'response_time_ms': parseFloat(tokens['response-time'](req, res)),
    'date': tokens.date(req, res, 'iso'),
    'timestamp': new Date().toISOString(),
    'http-version': tokens['http-version'](req, res),
    'user-agent': tokens['user-agent'](req, res),
    'remote-addr': tokens['remote-addr'](req, res),
    'server': 'custom-web'
  });
}, { stream: accessLogStream }));

app.get('/', (req, res) => {
  res.send('Serveur Web personnalisé avec logs en JSON');
});

app.get('/test', (req, res) => {
  res.json({ message: 'Test de logging JSON', timestamp: new Date().toISOString() });
});

app.get('/error', (req, res) => {
  res.status(500).json({ error: 'Erreur simulée', timestamp: new Date().toISOString() });
});

app.listen(PORT, () => {
  console.log(`Serveur démarré sur le port ${PORT}`);
});