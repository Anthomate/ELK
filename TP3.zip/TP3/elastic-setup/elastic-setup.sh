#!/bin/bash

echo "Attente du démarrage d'Elasticsearch..."
until curl -s -u elastic:changeme "http://elasticsearch:9200/_cluster/health?wait_for_status=yellow" > /dev/null; do
    echo "En attente d'Elasticsearch..."
    sleep 5
done
echo "Elasticsearch est prêt!"

echo "Création d'un rôle pour Filebeat..."
curl -X POST "http://elasticsearch:9200/_security/role/filebeat_writer" -H 'Content-Type: application/json' -u elastic:changeme -d'
{
  "cluster": ["monitor", "manage_index_templates", "manage_ilm", "manage_pipeline"],
  "indices": [
    {
      "names": ["filebeat-*", "apache-*", "nginx-*", "custom-*"],
      "privileges": ["create_doc", "create_index", "write", "create", "index", "manage", "manage_ilm"]
    }
  ]
}
'
echo

echo "Création d'un utilisateur pour Filebeat..."
curl -X POST "http://elasticsearch:9200/_security/user/filebeat_internal" -H 'Content-Type: application/json' -u elastic:changeme -d'
{
  "password" : "filebeat_password",
  "roles" : ["filebeat_writer"],
  "full_name" : "Filebeat Internal User"
}
'
echo

echo "Configuration terminée!"